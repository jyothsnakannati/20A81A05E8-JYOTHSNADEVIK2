export default function Total(props)
{
    return( 
    <div className="Total">Total -₹2000</div>
    )
}